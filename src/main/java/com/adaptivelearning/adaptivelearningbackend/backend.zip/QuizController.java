package com.adaptivelearning.adaptivelearningbackend;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/quiz")
@CrossOrigin(origins = "*")
public class QuizController {

    @Autowired
    private QuestionRepository questionRepository;

    @GetMapping("/questions")
    public List<Map<String, Object>> getQuestions(
            @RequestParam String topic,
            @RequestParam String difficulty) {

        List<Question> questions = questionRepository.findByTopicAndDifficulty(topic, difficulty);

        List<Map<String, Object>> safeQuestions = new ArrayList<>();

        for (Question q : questions) {
            Map<String, Object> item = new HashMap<>();
            item.put("id", q.getId());
            item.put("topic", q.getTopic());
            item.put("difficulty", q.getDifficulty());
            item.put("questionText", q.getQuestionText());
            item.put("optionA", q.getOptionA());
            item.put("optionB", q.getOptionB());
            item.put("optionC", q.getOptionC());
            item.put("optionD", q.getOptionD());

            // IMPORTANT: do NOT send correctAnswer to frontend
            safeQuestions.add(item);
        }

        return safeQuestions;
    }

    @PostMapping("/submit")
    public Map<String, Object> submitQuiz(@RequestBody QuizSubmission submission) {

        int correctCount = 0;

        for (AnswerItem answer : submission.answers) {
            Optional<Question> questionOpt = questionRepository.findById(answer.questionId);

            if (questionOpt.isPresent()) {
                Question question = questionOpt.get();

                if (question.getCorrectAnswer().equalsIgnoreCase(answer.selectedAnswer)) {
                    correctCount++;
                }
            }
        }

        Map<String, Object> result = new HashMap<>();
        result.put("totalItems", submission.answers.size());
        result.put("correctAnswers", correctCount);
        result.put("topic", submission.topic);
        result.put("difficulty", submission.difficulty);

        return result;
    }

    public static class QuizSubmission {
        public String topic;
        public String difficulty;
        public List<AnswerItem> answers;
    }

    public static class AnswerItem {
        public Long questionId;
        public String selectedAnswer;
    }
}