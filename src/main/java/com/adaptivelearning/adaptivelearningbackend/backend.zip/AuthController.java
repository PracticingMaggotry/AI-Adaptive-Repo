package com.adaptivelearning.adaptivelearningbackend;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.view.RedirectView;

import java.util.Optional;

@Controller
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/register")
    @ResponseBody
    public String registerUser(@RequestParam String fullName,
                               @RequestParam String email,
                               @RequestParam String password) {

        Optional<User> existingUser = userRepository.findByEmail(email);

        if (existingUser.isPresent()) {
            return "Email already exists. Please use another email.";
        }

        User user = new User(email, password, fullName);
        userRepository.save(user);

        return "Registration successful! You can now log in.";
    }

    @PostMapping("/login")
    @ResponseBody
    public Object loginUser(@RequestParam String email,
                            @RequestParam String password,
                            HttpSession session) {

        Optional<User> userOptional = userRepository.findByEmail(email);

        if (userOptional.isPresent()) {
            User user = userOptional.get();

            if (user.getPassword().equals(password)) {
                session.setAttribute("loggedInUserEmail", user.getEmail());
                session.setAttribute("loggedInUserName", user.getFullName());
                return new RedirectView("/dashboard.html");
            }
        }

        return "Invalid email or password.";
    }
}