package com.adaptivelearning.adaptivelearningbackend;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class RecoController {

    @Autowired
    private AttemptRepository attemptRepository;

    @PostMapping("/recommend")
    public Map<String, Object> recommend(@RequestBody AttemptRequest req, HttpSession session) {

        String studentId = (String) session.getAttribute("loggedInUserEmail");

        if (studentId == null || studentId.isBlank()) {
            studentId = "demo";
        }

        QuizAttempt attempt = new QuizAttempt(
                req.totalItems,
                req.correctAnswers,
                req.prevScore,
                req.difficulty
        );

        Results results = PerfAnalytics.analyze(attempt);

        Recommendation recommendation =
                RecoModule.reco(results, req.topic, req.difficulty);

        Attempt savedAttempt = new Attempt(
                studentId,
                req.topic,
                req.difficulty,
                req.totalItems,
                req.correctAnswers,
                results.getperformanceScore(),
                results.getnextDiff(),
                LocalDateTime.now()
        );

        attemptRepository.save(savedAttempt);

        Map<String, Object> recoMap = new HashMap<>();
        recoMap.put("nextTopic", recommendation.getNextTopic());
        recoMap.put("nextDiff", recommendation.getNextDiff());
        recoMap.put("reason", recommendation.getReason());

        Map<String, Object> response = new HashMap<>();
        response.put("results", results);
        response.put("recommendation", recoMap);
        response.put("history", attemptRepository.findByStudentIdOrderByTimestampDesc(studentId));

        return response;
    }

    @GetMapping("/history")
    public List<Attempt> history(HttpSession session) {
        String studentId = (String) session.getAttribute("loggedInUserEmail");

        if (studentId == null || studentId.isBlank()) {
            studentId = "demo";
        }

        return attemptRepository.findByStudentIdOrderByTimestampDesc(studentId);
    }

    @PostMapping("/reset")
    public void reset(HttpSession session) {
        String studentId = (String) session.getAttribute("loggedInUserEmail");

        if (studentId == null || studentId.isBlank()) {
            studentId = "demo";
        }

        List<Attempt> attempts = attemptRepository.findByStudentIdOrderByTimestampDesc(studentId);
        attemptRepository.deleteAll(attempts);
    }

    public static class AttemptRequest {
        public int totalItems;
        public int correctAnswers;
        public double prevScore;
        public String difficulty;
        public String topic;
    }
}