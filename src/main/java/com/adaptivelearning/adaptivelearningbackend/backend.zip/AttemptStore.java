package com.adaptivelearning.adaptivelearningbackend;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class AttemptStore {

    // Key: studentId, Value: list of attempt records
    private static final Map<String, List<AttemptRecord>> DB = new ConcurrentHashMap<>();

    public static void add(String studentId, AttemptRecord record) {
        DB.computeIfAbsent(studentId, k -> new ArrayList<>()).add(record);
    }

    public static List<AttemptRecord> getAll(String studentId) {
        return DB.getOrDefault(studentId, Collections.emptyList());
    }

    public static void clear(String studentId) {
        DB.remove(studentId);
    }

    public static class AttemptRecord {
        public String topic;
        public String difficulty;
        public int totalItems;
        public int correctAnswers;
        public double performanceScore;
        public String nextDiff;
        public long timestamp;

        public AttemptRecord(String topic, String difficulty, int totalItems, int correctAnswers,
                             double performanceScore, String nextDiff) {
            this.topic = topic;
            this.difficulty = difficulty;
            this.totalItems = totalItems;
            this.correctAnswers = correctAnswers;
            this.performanceScore = performanceScore;
            this.nextDiff = nextDiff;
            this.timestamp = System.currentTimeMillis();
        }
    }
}