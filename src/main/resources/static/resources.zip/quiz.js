let quizQuestions = [];

async function loadQuiz() {
    try {
        const topic = sessionStorage.getItem("quizTopic") || "Programming";
        const difficulty = sessionStorage.getItem("quizDifficulty") || "Medium";

        const header = document.getElementById("quizHeader");
        if (header) {
            header.textContent = `${topic} Quiz (${difficulty.toUpperCase()})`;
        }

        const res = await fetch(`/api/quiz/questions?topic=${topic}&difficulty=${difficulty}`);
        quizQuestions = await res.json();

        console.log("Loaded quiz questions:", quizQuestions);

        const quizBox = document.getElementById("quizBox");
        if (!quizBox) return;

        quizBox.innerHTML = "";

        if (!quizQuestions || quizQuestions.length === 0) {
            quizBox.innerHTML = `<p>No quiz questions found for this topic and difficulty.</p>`;
            return;
        }

        quizQuestions.forEach((q, index) => {
            const card = document.createElement("div");
            card.className = "question-card";

            card.innerHTML = `
                <div class="question-title">${index + 1}. ${q.questionText}</div>
                <label class="option"><input type="radio" name="q${q.id}" value="A"> ${q.optionA}</label><br>
                <label class="option"><input type="radio" name="q${q.id}" value="B"> ${q.optionB}</label><br>
                <label class="option"><input type="radio" name="q${q.id}" value="C"> ${q.optionC}</label><br>
                <label class="option"><input type="radio" name="q${q.id}" value="D"> ${q.optionD}</label>
            `;

            quizBox.appendChild(card);
        });
    } catch (err) {
        console.error("loadQuiz error:", err);
        const quizBox = document.getElementById("quizBox");
        if (quizBox) {
            quizBox.innerHTML = `<p>Failed to load quiz questions.</p>`;
        }
    }
}

async function submitQuiz() {
    try {
        const topic = sessionStorage.getItem("quizTopic") || "Programming";
        const difficulty = sessionStorage.getItem("quizDifficulty") || "Medium";

        const unanswered = quizQuestions.filter(q => {
            return !document.querySelector(`input[name="q${q.id}"]:checked`);
        });

        if (unanswered.length > 0) {
            alert("Please answer all questions before submitting.");
            return;
        }

        const answers = quizQuestions.map(q => {
            const selected = document.querySelector(`input[name="q${q.id}"]:checked`);
            return {
                questionId: q.id,
                selectedAnswer: selected ? selected.value : ""
            };
        });

        const quizPayload = {
            topic: topic,
            difficulty: difficulty,
            answers: answers
        };

        console.log("Submitting quiz payload:", quizPayload);

        const quizResultRes = await fetch("/api/quiz/submit", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(quizPayload)
        });

        const quizResult = await quizResultRes.json();
        console.log("Quiz checked:", quizResult);

        const recoPayload = {
            totalItems: quizResult.totalItems,
            correctAnswers: quizResult.correctAnswers,
            prevScore: 0,
            difficulty: quizResult.difficulty,
            topic: quizResult.topic
        };

        console.log("Submitting recommendation payload:", recoPayload);

        const recoRes = await fetch("/api/recommend", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(recoPayload)
        });

        const recoData = await recoRes.json();
        console.log("Recommendation result:", recoData);

        sessionStorage.setItem("latestQuizResult", JSON.stringify(quizResult));
        sessionStorage.setItem("latestRecoData", JSON.stringify(recoData));

        alert(
            `Score: ${quizResult.correctAnswers}/${quizResult.totalItems}\n` +
            `Recommendation: ${recoData.recommendation.reason}`
        );

        window.location.href = "/dashboard.html?refresh=true";
    } catch (err) {
        console.error("submitQuiz error:", err);
        alert("Something went wrong while submitting the quiz.");
    }
}

document.addEventListener("DOMContentLoaded", () => {
    console.log("quiz.js loaded");
    loadQuiz();
});