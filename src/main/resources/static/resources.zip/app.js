async function loadLoggedInUser() {
    try {
        const res = await fetch("/api/me");
        const data = await res.json();

        const userName = document.getElementById("userName");
        const userSub = document.getElementById("userSub");

        if (userName) userName.textContent = data.name || "Student";
        if (userSub) userSub.textContent = data.email || "No email";
    } catch (err) {
        console.error("loadLoggedInUser error:", err);
    }
}

function loadLatestSessionResult() {
    const recoDataRaw = sessionStorage.getItem("latestRecoData");
    const quizResultRaw = sessionStorage.getItem("latestQuizResult");

    if (!recoDataRaw || !quizResultRaw) return;

    const recoData = JSON.parse(recoDataRaw);
    const quizResult = JSON.parse(quizResultRaw);

    const perf = document.getElementById("kpiPerformance");
    if (perf) {
        perf.textContent = Math.round(recoData.results.performanceScore) + "%";
    }

    const prog = document.getElementById("kpiProgress");
    if (prog) {
        const p = Math.round(recoData.results.progress);
        prog.textContent = (p > 0 ? "+" : "") + p + "%";
    }

    const diffEl = document.getElementById("kpiDifficulty");
    if (diffEl) {
        diffEl.textContent = (recoData.results.nextDiff || "").toUpperCase();
    }

    const rTopic = document.getElementById("recoTopic");
    if (rTopic) rTopic.textContent = recoData.recommendation.nextTopic || "--";

    const rReason = document.getElementById("recoReason");
    if (rReason) rReason.textContent = recoData.recommendation.reason || "--";
}

async function loadDashboardData() {
    try {
        const res = await fetch("/api/history");
        const history = await res.json();

        console.log("History:", history);

        if (!history || history.length === 0) return;

        const latest = history[0];

        const perf = document.getElementById("kpiPerformance");
        if (perf) {
            perf.textContent = Math.round(latest.performanceScore) + "%";
        }

        const diffEl = document.getElementById("kpiDifficulty");
        if (diffEl) {
            diffEl.textContent = (latest.nextDiff || latest.difficulty || "").toUpperCase();
        }

        const recoTopic = document.getElementById("recoTopic");
        if (recoTopic) {
            recoTopic.textContent = latest.topic || "--";
        }

        const recoReason = document.getElementById("recoReason");
        if (recoReason) {
            if ((latest.performanceScore || 0) < 50) {
                recoReason.textContent = "Needs improvement. Review this topic again.";
            } else if ((latest.performanceScore || 0) < 80) {
                recoReason.textContent = "Stay on this level and practice more.";
            } else {
                recoReason.textContent = "Good job! Ready for the next challenge.";
            }
        }

        renderRecentActivity(history);
    } catch (err) {
        console.error("loadDashboardData error:", err);
    }
}

function renderRecentActivity(history) {
    const activityBox = document.querySelector(".activity");
    if (!activityBox) return;

    activityBox.innerHTML = "";

    history.slice(0, 5).forEach(item => {
        const div = document.createElement("div");
        div.className = "activity-item";

        div.innerHTML = `
            <div class="activity-left">
                <div class="mini-icon">🧪</div>
                <div>
                    <div class="activity-title">Adaptive Quiz • ${item.topic}</div>
                    <div class="muted">Score: ${Math.round(item.performanceScore)}% • Difficulty: ${item.difficulty}</div>
                </div>
            </div>
            <div class="muted">${formatTimestamp(item.timestamp)}</div>
        `;

        activityBox.appendChild(div);
    });
}

function formatTimestamp(timestamp) {
    if (!timestamp) return "Unknown time";

    const date = new Date(timestamp);
    if (isNaN(date.getTime())) return "Recently";

    return date.toLocaleString();
}

document.addEventListener("DOMContentLoaded", () => {
    loadLoggedInUser();

    const urlParams = new URLSearchParams(window.location.search);

    if (urlParams.get("refresh")) {
        // force reload latest data
        setTimeout(() => {
            loadDashboardData();
        }, 300);
    } else {
        loadLatestSessionResult();
        loadDashboardData();
    }

    const btn = document.getElementById("takeAdaptiveQuizBtn");

    if (btn) {
        btn.addEventListener("click", () => {

            const topic = document.getElementById("recoTopic")?.textContent || "Programming";
            const difficulty = document.getElementById("kpiDifficulty")?.textContent || "Medium";

            sessionStorage.setItem("quizTopic", topic);
            sessionStorage.setItem("quizDifficulty", difficulty);

            console.log("Starting quiz:", topic, difficulty);

            window.location.href = "/quiz.html";
        });
    }
});