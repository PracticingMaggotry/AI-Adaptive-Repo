const ctx = document.getElementById("learningChart");

const learningChart = new Chart(ctx, {
    type: "line",
    data: {
        labels: ["Attempt 1","Attempt 2","Attempt 3","Attempt 4","Attempt 5"],
        datasets: [{
            label: "Performance",
            data: [50, 60, 65, 70, 75],
            tension: 0.3
        }]
    },
    options: {
        responsive: true
    }
});